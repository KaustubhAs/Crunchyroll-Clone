package com.example.bottomnavigationbarcomposeexample

import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

class Watching(@StringRes val stringResourceId: Int,
               @StringRes val stringResourceId2: Int,
               @StringRes val stringResourceId3: Int,
               @DrawableRes val imageResourceId: Int,
               @DrawableRes val imageResourceId2: Int) {
}