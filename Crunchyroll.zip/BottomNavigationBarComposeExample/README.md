![logo](https://i.imgur.com/Dv73hCk.png)
# BottomNavigationBarComposeExample
Create Bottom Navigation Bar with Jetpack Compose

https://johncodeos.com/how-to-create-bottom-navigation-bar-with-jetpack-compose/
